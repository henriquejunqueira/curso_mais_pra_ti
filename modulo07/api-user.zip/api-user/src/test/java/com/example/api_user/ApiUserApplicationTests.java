package com.example.api_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
